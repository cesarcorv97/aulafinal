
import React from 'react';

interface HeaderProps {
  onGoHome: () => void;
}

const Header: React.FC<HeaderProps> = ({ onGoHome }) => {
  return (
    <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-slate-200 dark:border-[#233648] px-6 py-4 md:px-10 bg-white dark:bg-[#111a22] sticky top-0 z-50">
      <div 
        className="flex items-center gap-3 cursor-pointer select-none" 
        onClick={onGoHome}
      >
        <div className="flex items-center justify-center text-primary">
          <span className="material-symbols-outlined text-3xl">graphic_eq</span>
        </div>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em]">AulaIA</h2>
      </div>
      <div className="flex items-center gap-4 md:gap-8">
        <div className="flex gap-2">
          <button className="flex items-center justify-center rounded-lg size-10 hover:bg-slate-100 dark:hover:bg-[#233648] text-slate-500 dark:text-white transition-colors" title="Ajustes">
            <span className="material-symbols-outlined">settings</span>
          </button>
          <button className="flex items-center justify-center rounded-lg size-10 hover:bg-slate-100 dark:hover:bg-[#233648] text-slate-500 dark:text-white transition-colors" title="Perfil">
            <span className="material-symbols-outlined">person</span>
          </button>
        </div>
        <div 
          className="bg-center bg-no-repeat bg-cover rounded-full size-10 border border-slate-200 dark:border-slate-700" 
          style={{ backgroundImage: 'url("https://picsum.photos/seed/student/80/80")' }}
        />
      </div>
    </header>
  );
};

export default Header;
