
import React from 'react';
import { Lecture } from '../types';

interface LectureCardProps {
  lecture: Lecture;
  onClick: (lecture: Lecture) => void;
}

const LectureCard: React.FC<LectureCardProps> = ({ lecture, onClick }) => {
  return (
    <div 
      className="flex items-center gap-4 bg-white dark:bg-[#182635] border border-slate-200 dark:border-[#233648] rounded-xl px-4 py-4 justify-between transition-all cursor-pointer hover:scale-[1.01] hover:shadow-md active:scale-95 group"
      onClick={() => onClick(lecture)}
    >
      <div className="flex items-center gap-4 overflow-hidden">
        <div className="flex items-center justify-center rounded-lg bg-blue-50 dark:bg-[#233648] shrink-0 size-12 text-primary group-hover:bg-primary group-hover:text-white transition-colors">
          <span className="material-symbols-outlined">audio_file</span>
        </div>
        <div className="flex flex-col justify-center min-w-0 text-left">
          <p className="text-slate-900 dark:text-white text-base font-semibold leading-normal truncate">
            {lecture.title}
          </p>
          <div className="flex items-center gap-2 text-slate-500 dark:text-[#92adc9] text-sm font-normal">
            <span>{lecture.processedAt}</span>
            <span className="size-1 bg-slate-400 rounded-full"></span>
            <span>{lecture.duration}</span>
          </div>
        </div>
      </div>
      <div className="shrink-0">
        <button className="flex items-center justify-center size-10 rounded-full hover:bg-slate-100 dark:hover:bg-[#233648] text-slate-400 dark:text-slate-300 transition-colors">
          <span className="material-symbols-outlined">chevron_right</span>
        </button>
      </div>
    </div>
  );
};

export default LectureCard;
