
import React from 'react';
import { Lecture } from '../types';

interface DetailViewProps {
  lecture: Lecture;
  onBack: () => void;
}

const DetailView: React.FC<DetailViewProps> = ({ lecture, onBack }) => {
  return (
    <div className="flex flex-col w-full max-w-[900px] gap-8 animate-in fade-in duration-500">
      <div className="flex items-center gap-4">
        <button 
          onClick={onBack}
          className="flex items-center justify-center size-10 rounded-full hover:bg-slate-100 dark:hover:bg-[#233648] text-slate-500 dark:text-white transition-colors"
          title="Volver"
        >
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <div className="flex flex-col">
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            {lecture.title}
          </h1>
          <p className="text-slate-500 dark:text-[#92adc9] text-sm">
            {lecture.duration} • {lecture.fileName}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <section className="bg-white dark:bg-[#182635] p-6 rounded-2xl border border-slate-200 dark:border-[#233648]">
            <div className="flex items-center gap-2 mb-4 text-primary">
              <span className="material-symbols-outlined">description</span>
              <h3 className="font-bold text-lg">Resumen con IA</h3>
            </div>
            <div className="prose prose-slate dark:prose-invert max-w-none text-slate-700 dark:text-[#92adc9] whitespace-pre-line">
              {lecture.summary || "Procesando resumen..."}
            </div>
          </section>

          <section className="bg-white dark:bg-[#182635] p-6 rounded-2xl border border-slate-200 dark:border-[#233648]">
            <div className="flex items-center gap-2 mb-4 text-primary">
              <span className="material-symbols-outlined">history_edu</span>
              <h3 className="font-bold text-lg">Transcripción</h3>
            </div>
            <div className="max-h-[500px] overflow-y-auto pr-2 custom-scrollbar text-slate-600 dark:text-[#92adc9] leading-relaxed">
              {lecture.transcript || "La transcripción está pendiente..."}
            </div>
          </section>
        </div>

        <div className="flex flex-col gap-6">
          <div className="bg-white dark:bg-[#182635] p-6 rounded-2xl border border-slate-200 dark:border-[#233648]">
            <h4 className="font-bold mb-4">Detalles del Archivo</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex justify-between">
                <span className="text-slate-500">Formato</span>
                <span className="text-slate-900 dark:text-white font-medium uppercase">{lecture.fileName.split('.').pop()}</span>
              </li>
              <li className="flex justify-between">
                <span className="text-slate-500">Tamaño</span>
                <span className="text-slate-900 dark:text-white font-medium">{(lecture.fileSize / (1024 * 1024)).toFixed(1)} MB</span>
              </li>
              <li className="flex justify-between">
                <span className="text-slate-500">Subido</span>
                <span className="text-slate-900 dark:text-white font-medium">{lecture.processedAt}</span>
              </li>
            </ul>
            <button className="w-full mt-6 py-3 px-4 bg-slate-100 dark:bg-[#233648] hover:bg-slate-200 dark:hover:bg-[#2d4358] rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-colors">
              <span className="material-symbols-outlined text-sm">download</span>
              Descargar PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailView;
